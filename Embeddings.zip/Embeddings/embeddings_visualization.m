clear; close all;
rng(1991);

graph_cases = {
    "8blocks_500nodes.mat",
    "8blocks_500nodes_unsorted.mat",
};

%% Initialize results
nc = length(graph_cases);

for i = 1:nc
    % Load graph
    loaded = load(graph_cases{i});
    W      = loaded.W;
    labels = loaded.labels;
    
    % Get number of labels
    k = size(unique(labels), 1);

    % Get embeddings
    [Z_unscaled, Z_scaled] = SVD_embeddings(W, k);

    % Dimensionality reduction using tSNE
    Y_unscaled = tsne(Z_unscaled);
    Y_scaled   = tsne(Z_scaled);

    % Plot
    figure;
    gscatter(Y_unscaled(:,1),Y_unscaled(:,2),labels);
    title(sprintf("Unscaled adjacency spectral embedding - %s", graph_cases{i}), "Interpreter","none");

    figure;
    gscatter(Y_scaled(:,1),Y_scaled(:,2),labels);
    title(sprintf("Scaled adjacency spectral embedding - %s", graph_cases{i}), "Interpreter","none");
end